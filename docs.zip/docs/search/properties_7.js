var searchData=
[
  ['nazwaumowy_364',['NazwaUmowy',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_umowas_row.html#a443b4784d04e1dfeaebacfa57125cf78',1,'ProjektHR.DefConnPracDataSet.UmowasRow.NazwaUmowy()'],['../class_projekt_h_r_1_1_models_1_1_umowa.html#a8afab05bd0917207876741d3a4c9628c',1,'ProjektHR.Models.Umowa.NazwaUmowy()']]],
  ['nazwaumowycolumn_365',['NazwaUmowyColumn',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_umowas_data_table.html#a5cecb9474e419300ef30dc4c0fb93a96',1,'ProjektHR::DefConnPracDataSet::UmowasDataTable']]],
  ['nazwisko_366',['Nazwisko',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_row.html#a82d343c87edfc16dd668ea2aa63e72fb',1,'ProjektHR.DefConnPracDataSet.PracowniksRow.Nazwisko()'],['../class_projekt_h_r_1_1_models_1_1_pracownik.html#a1163cb0eadffd43073b1edc29f9e5b35',1,'ProjektHR.Models.Pracownik.Nazwisko()']]],
  ['nazwiskocolumn_367',['NazwiskoColumn',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_data_table.html#a5582e5bcda2596e417dd8497f5328a14',1,'ProjektHR::DefConnPracDataSet::PracowniksDataTable']]],
  ['netto_368',['Netto',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_wyplatas_row.html#a262b9537b063a454cfa4ffd2694e60b1',1,'ProjektHR.DefConnPracDataSet.WyplatasRow.Netto()'],['../class_projekt_h_r_1_1_models_1_1_wyplata.html#a5cf6f38918108219e548932e33e380fd',1,'ProjektHR.Models.Wyplata.Netto()']]],
  ['nettocolumn_369',['NettoColumn',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_wyplatas_data_table.html#ad5b76149534733c9c3e9cd6c39c80fd9',1,'ProjektHR::DefConnPracDataSet::WyplatasDataTable']]]
];
