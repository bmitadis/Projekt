var searchData=
[
  ['insertupdatedelete_333',['InsertUpdateDelete',['../class_projekt_h_r_1_1_def_conn_prac_data_set_table_adapters_1_1_table_adapter_manager.html#a986ead5d8487065578f96cfb492521cda27b77cb15d3da7ded0250d0001bc6755',1,'ProjektHR::DefConnPracDataSetTableAdapters::TableAdapterManager']]]
];
