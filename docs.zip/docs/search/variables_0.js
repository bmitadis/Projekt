var searchData=
[
  ['dbcontext_331',['dbcontext',['../class_projekt_h_r_1_1_main_window.html#ae5ada93883adc97c7a8cef92d4d1bdc8',1,'ProjektHR::MainWindow']]]
];
