var searchData=
[
  ['readxmlserializable_124',['ReadXmlSerializable',['../class_projekt_h_r_1_1_def_conn_prac_data_set.html#a1c26ea76e55363980349415ab746792e',1,'ProjektHR::DefConnPracDataSet']]],
  ['relations_125',['Relations',['../class_projekt_h_r_1_1_def_conn_prac_data_set.html#a22f534c17b12e0116319b64fcfa5a3a7',1,'ProjektHR::DefConnPracDataSet']]],
  ['remove_5f_5fmigrationhistoryrow_126',['Remove__MigrationHistoryRow',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_____migration_history_data_table.html#ac23f51feecd6c4b48eb6599b4e62a09a',1,'ProjektHR::DefConnPracDataSet::__MigrationHistoryDataTable']]],
  ['removepracowniksrow_127',['RemovePracowniksRow',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_data_table.html#aa10376cb4ebc8b96c37bc8d2667d8c31',1,'ProjektHR::DefConnPracDataSet::PracowniksDataTable']]],
  ['removeumowasrow_128',['RemoveUmowasRow',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_umowas_data_table.html#a2e1cbeec89e6d373bc8adcc2e4fbf752',1,'ProjektHR::DefConnPracDataSet::UmowasDataTable']]],
  ['removewyplatasrow_129',['RemoveWyplatasRow',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_wyplatas_data_table.html#a81db5e423d26825408fe3c721c780093',1,'ProjektHR::DefConnPracDataSet::WyplatasDataTable']]],
  ['resources_2edesigner_2ecs_130',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]],
  ['row_131',['Row',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_row_change_event.html#ac9236368a9692effccc98943170659ea',1,'ProjektHR.DefConnPracDataSet.PracowniksRowChangeEvent.Row()'],['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_umowas_row_change_event.html#a0ae00b4431122e91056885e46133f3ea',1,'ProjektHR.DefConnPracDataSet.UmowasRowChangeEvent.Row()'],['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_wyplatas_row_change_event.html#af1db5513f2c5a490477b3d37d29a7554',1,'ProjektHR.DefConnPracDataSet.WyplatasRowChangeEvent.Row()'],['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_____migration_history_row_change_event.html#a138dd2394e579f2b07c9550d4e7715a1',1,'ProjektHR.DefConnPracDataSet.__MigrationHistoryRowChangeEvent.Row()']]]
];
