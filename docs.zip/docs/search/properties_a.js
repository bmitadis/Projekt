var searchData=
[
  ['relations_381',['Relations',['../class_projekt_h_r_1_1_def_conn_prac_data_set.html#a22f534c17b12e0116319b64fcfa5a3a7',1,'ProjektHR::DefConnPracDataSet']]],
  ['row_382',['Row',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_row_change_event.html#ac9236368a9692effccc98943170659ea',1,'ProjektHR.DefConnPracDataSet.PracowniksRowChangeEvent.Row()'],['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_umowas_row_change_event.html#a0ae00b4431122e91056885e46133f3ea',1,'ProjektHR.DefConnPracDataSet.UmowasRowChangeEvent.Row()'],['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_wyplatas_row_change_event.html#af1db5513f2c5a490477b3d37d29a7554',1,'ProjektHR.DefConnPracDataSet.WyplatasRowChangeEvent.Row()'],['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_____migration_history_row_change_event.html#a138dd2394e579f2b07c9550d4e7715a1',1,'ProjektHR.DefConnPracDataSet.__MigrationHistoryRowChangeEvent.Row()']]]
];
