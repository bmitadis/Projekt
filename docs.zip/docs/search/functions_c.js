var searchData=
[
  ['readxmlserializable_296',['ReadXmlSerializable',['../class_projekt_h_r_1_1_def_conn_prac_data_set.html#a1c26ea76e55363980349415ab746792e',1,'ProjektHR::DefConnPracDataSet']]],
  ['remove_5f_5fmigrationhistoryrow_297',['Remove__MigrationHistoryRow',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_____migration_history_data_table.html#ac23f51feecd6c4b48eb6599b4e62a09a',1,'ProjektHR::DefConnPracDataSet::__MigrationHistoryDataTable']]],
  ['removepracowniksrow_298',['RemovePracowniksRow',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_data_table.html#aa10376cb4ebc8b96c37bc8d2667d8c31',1,'ProjektHR::DefConnPracDataSet::PracowniksDataTable']]],
  ['removeumowasrow_299',['RemoveUmowasRow',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_umowas_data_table.html#a2e1cbeec89e6d373bc8adcc2e4fbf752',1,'ProjektHR::DefConnPracDataSet::UmowasDataTable']]],
  ['removewyplatasrow_300',['RemoveWyplatasRow',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_wyplatas_data_table.html#a81db5e423d26825408fe3c721c780093',1,'ProjektHR::DefConnPracDataSet::WyplatasDataTable']]]
];
