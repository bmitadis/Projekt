var searchData=
[
  ['app_2examl_2ecs_231',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]],
  ['applicationdbcontext_2ecs_232',['ApplicationDbContext.cs',['../_application_db_context_8cs.html',1,'']]],
  ['assemblyinfo_2ecs_233',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
