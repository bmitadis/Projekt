var searchData=
[
  ['pracowniksrowchanged_412',['PracowniksRowChanged',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_data_table.html#ab012fc2a7f91ea950180533dae1e77ff',1,'ProjektHR::DefConnPracDataSet::PracowniksDataTable']]],
  ['pracowniksrowchanging_413',['PracowniksRowChanging',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_data_table.html#a025022db36b9e0b663e4a593400c08bc',1,'ProjektHR::DefConnPracDataSet::PracowniksDataTable']]],
  ['pracowniksrowdeleted_414',['PracowniksRowDeleted',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_data_table.html#ad7272dbc70c6ba8f4691694be28adee8',1,'ProjektHR::DefConnPracDataSet::PracowniksDataTable']]],
  ['pracowniksrowdeleting_415',['PracowniksRowDeleting',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_pracowniks_data_table.html#a96228e20e0cce85973e426732fc9d7bd',1,'ProjektHR::DefConnPracDataSet::PracowniksDataTable']]]
];
