var searchData=
[
  ['defconnpracdataset_2edesigner_2ecs_235',['DefConnPracDataSet.Designer.cs',['../_def_conn_prac_data_set_8_designer_8cs.html',1,'']]]
];
