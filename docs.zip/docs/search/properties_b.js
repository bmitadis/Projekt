var searchData=
[
  ['schemaserializationmode_383',['SchemaSerializationMode',['../class_projekt_h_r_1_1_def_conn_prac_data_set.html#a307c7f31c58c68aa3aa8099a92d58b00',1,'ProjektHR::DefConnPracDataSet']]],
  ['stawka_384',['Stawka',['../class_projekt_h_r_1_1_models_1_1_pracownik.html#a745110932774d64f7e50f58dc2788bf2',1,'ProjektHR::Models::Pracownik']]]
];
