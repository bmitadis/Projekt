var searchData=
[
  ['tostring_313',['ToString',['../class_projekt_h_r_1_1_models_1_1_pracownik.html#ac0974d23051fc1f475f657141e1e83a2',1,'ProjektHR.Models.Pracownik.ToString()'],['../class_projekt_h_r_1_1_models_1_1_umowa.html#a478843bbed518ec40cd2c4b65a774ccf',1,'ProjektHR.Models.Umowa.ToString()']]]
];
