var searchData=
[
  ['updateinsertdelete_334',['UpdateInsertDelete',['../class_projekt_h_r_1_1_def_conn_prac_data_set_table_adapters_1_1_table_adapter_manager.html#a986ead5d8487065578f96cfb492521cda894fcc001e51f673d3fb5f3096473dd8',1,'ProjektHR::DefConnPracDataSetTableAdapters::TableAdapterManager']]]
];
