var searchData=
[
  ['okres_370',['Okres',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_wyplatas_row.html#ae094c326afc47535fe91110cc854ade8',1,'ProjektHR.DefConnPracDataSet.WyplatasRow.Okres()'],['../class_projekt_h_r_1_1_models_1_1_wyplata.html#ae5909a028f4afe6cf865b8ff35ea5910',1,'ProjektHR.Models.Wyplata.Okres()']]],
  ['okrescolumn_371',['OkresColumn',['../class_projekt_h_r_1_1_def_conn_prac_data_set_1_1_wyplatas_data_table.html#a12f339078b953ac607ac269735a48466',1,'ProjektHR::DefConnPracDataSet::WyplatasDataTable']]]
];
