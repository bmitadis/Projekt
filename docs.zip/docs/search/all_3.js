var searchData=
[
  ['backupdatasetbeforeupdate_24',['BackupDataSetBeforeUpdate',['../class_projekt_h_r_1_1_def_conn_prac_data_set_table_adapters_1_1_table_adapter_manager.html#ae3b66309b49c2ad365040e2fec23c64d',1,'ProjektHR::DefConnPracDataSetTableAdapters::TableAdapterManager']]],
  ['brutto_25',['Brutto',['../class_projekt_h_r_1_1_models_1_1_wyplata.html#ae0f15b73cc3a2c1da90b70ce685b2422',1,'ProjektHR::Models::Wyplata']]]
];
